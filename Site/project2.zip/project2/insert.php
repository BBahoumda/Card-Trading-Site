<html>
<head>
  <title>Card Trade Results</title>
</head>
<body>
<h1>Card Trade Entry Results</h1>
<?php
  // create short variable names
  $id=$_POST['id'];
  $product_code=$_POST['$product_code'];
  $product_name=$_POST['$product_name'];
  $product_desc=$_POST['$product_desc'];
  $product_img=$_POST['$img'];
  $price=$_POST['price'];
  
  echo $id, $product_name, $product_code, $product_desc, $product_img, $price;

  if (!$id || !$product_cname || !$product_code|| !$product_desc || $product_img || $price) {
     echo "You have not entered all the required details.<br />"
          ."Please go back and try again.";
     exit;
  }

  if (!get_magic_quotes_gpc()) {
    $id = addslashes($isbn);
    $product_code = addslashes($author);
    $product_name = addslashes($title);
    $product_desc = doubleval($price);
    $product_img = addslashes($img);
  }
/*dbServer = "localhost";
$dbUsername = "bahoumd1";
$dbPass = "Faith02101";
$dbName = "bahoumd1_project";

*/
  @ $db = new mysqli('localhost', 'bahoumd1', 'Faith02101', 'bahoumd1_project2');

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }

  $query = "insert into products values
            ('".$id."', '".$product_cname."', '".$product_code."', '".$product_desc."', '".$product_img."', '".$price."',)";
  $result = $db->query($query);

  if ($result) {
      echo  $db->affected_rows." product inserted into database.";
  } else {
  	  echo "An error has occurred.  The item was not added.";
  }

  $db->close();
?>
</body>
</html>
